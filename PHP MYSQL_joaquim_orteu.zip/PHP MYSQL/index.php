<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }
  </style>
</head>
<body>
        <h2 class="text-center pt-5 pb-3 ">Afegir productes</h2>

    <form action="index.php" method="post" enctype="multipart/form-data">

  <label for="">Origen</label>
    <input class="form-control" type="text" name="origen" id="" required><br>
  <label for="">Desti</label>
    <input class="form-control" type="text" name="desti" id="" required><br>
  <label for="">Preu</label>
    <input class="form-control" type="number" name="preu" id="" required><br>
  <label for="">Foto</label>
    <input class="form-control" type="file" name="foto" id="" required><br>
  <label for="">Nombre de plaçes</label>
    <input class="form-control" type="text" name="plaçes" id="" required><br>
    <input class="btn btn-primary" type="submit" name="registrar" value="Registrar">
</form>

<?php
 $mysql=new mysqli('localhost','root','','vols');
 if($mysql->connect_errno){
     die($mysql->connect_error);
 }
 $mysql->set_charset('utf8');

if(isset($_POST["registrar"])){
     $origen=$_POST['origen'];
    $desti=$_POST['desti'];
    $preu=$_POST['preu'];
  //$foto=$_POST['foto'];
    $plaçes=$_POST['plaçes'];

    $today = date("YmdHis");
    $extensio = substr($_FILES['foto']['name'], strpos($_FILES['foto']['name'],"."));
    $nom = substr($_FILES['foto']['name'],0, strpos($_FILES['foto']['name'],"."));
    $nomcomplet = $nom . $today . $extensio;
    copy($_FILES['foto']['tmp_name'], "img/" . $nomcomplet);
    // $_SESSION["foto"][]= "img/" . $nomcomplet;
    $mysql=new mysqli('localhost','root','','vols');
    if($mysql->connect_errno){
        die($mysql->connect_error);
    }
    $sql="INSERT INTO vol (origen,desti,preu,foto,nombre_places) VALUES ('$origen','$desti','$preu', '$nomcomplet', '$plaçes')";
    $result=$mysql->query($sql);

    header("Location:../index.php");
}
?>

</body>
</html>