<form action="index.php?controller=usuari&action=guardarusuari" method="post">

    <div class="form-group">
        <label for="dni">DNI</label>
        <input type="text" class="form-control" id="dni" name="dni" placeholder="DNI">
    </div>
    <div class="form-group">
        <label for="nom">Nom</label>
        <input type="text" class="form-control" id="nom" name="nom" placeholder="Nom">
    </div>
    <div class="form-group">
        <label for="correu">Correu</label>
        <input type="text" class="form-control" id="correu" name="correu" placeholder="Correu">
    </div>
    <div class="form-group">
        <label for="adreça">Adreça</label>
        <input type="text" class="form-control" id="adreça" name="adreça" placeholder="Adreça">
    </div>
    <div class="form-group">
        <label for="telefon">Telefon</label>
        <input type="text" class="form-control" id="telefon" name="telefon" placeholder="Telefon">
    </div>
    <div class="form-group">
        <label for="num_tarjeta">Num tarjeta</label>
        <input type="text" class="form-control" id="num_tarjeta" name="num_tarjeta" placeholder="Num tarjeta">
    </div>
    <div class="form-group">
        <label for="contrasenya">Contrasenya</label>
        <input type="text" class="form-control" id="contrasenya" name="contrasenya" placeholder="contrasenya">
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>

</form>