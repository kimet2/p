<form action="index.php?controller=vol&action=guardarvols" method="post">

    <div class="form-group">
        <label for="origen">Origen</label>
        <input type="text" class="form-control" id="origen" name="origen" placeholder="Origen">
    </div>
    <div class="form-group">
        <label for="desti">Desti</label>
        <input type="text" class="form-control" id="desti" name="desti" placeholder="Desti">
    </div>
    <div class="form-group">
        <label for="preu">Preu</label>
        <input type="text" class="form-control" id="preu" name="preu" placeholder="Preu">
    </div>
    <div class="form-group">
        <label for="foto">Foto</label>
        <input type="text" class="form-control" id="foto" name="foto" placeholder="Foto">
    </div>
    <div class="form-group">
        <label for="nombre_places">Nombre places</label>
        <input type="text" class="form-control" id="nombre_places" name="nombre_places" placeholder="Nombre places">
    </div>
    <br>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>